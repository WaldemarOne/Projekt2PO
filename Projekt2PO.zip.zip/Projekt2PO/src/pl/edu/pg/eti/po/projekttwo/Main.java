package pl.edu.pg.eti.po.projekttwo;
public class Main {
    public static void main(String[] args) {
        SwiatGUI swiatGUI = new SwiatGUI("Wirtualny swiat");
    }
}