package pl.edu.pg.eti.po.projekttwo.animal;

import pl.edu.pg.eti.po.projekttwo.Animal;
import pl.edu.pg.eti.po.projekttwo.Swiat;
import pl.edu.pg.eti.po.projekttwo.Punkt;

import java.awt.*;
public class Owca extends Animal{
    private static final int ZASIEG_RUCHU_OWCY = 1;
    private static final int SZANSA_WYKONYWANIA_RUCHU_OWCA = 1;
    private static final int SILA_OWCY = 4;
    private static final int INICJATYWA_OWCY = 4;

    public Owca(Swiat swiat, Punkt pozycja, int turaUrodzenia) {
        super(TypOrganizmu.OWCA, swiat, pozycja, turaUrodzenia, SILA_OWCY, INICJATYWA_OWCY);
        this.setZasiegRuchu(ZASIEG_RUCHU_OWCY);
        this.setSzansaWykonywaniaRuchu(SZANSA_WYKONYWANIA_RUCHU_OWCA);
        setKolor(new Color(255, 153, 204));
    }

    @Override
    public String TypOrganizmuToString() {
        return "Owca";
    }
}
