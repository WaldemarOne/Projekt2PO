package pl.edu.pg.eti.po.projekttwo.animal;

import pl.edu.pg.eti.po.projekttwo.Animal;
import pl.edu.pg.eti.po.projekttwo.Swiat;
import pl.edu.pg.eti.po.projekttwo.Punkt;
import pl.edu.pg.eti.po.projekttwo.Animal;

import java.awt.*;

public class Wilk extends Animal {
    private static final int ZASIEG_RUCHU_WILKA = 1;
    private static final int SZANSA_WYKONYWANIA_RUCHU_WILKA = 1;
    private static final int SILA_WILKA = 9;
    private static final int INICJATYWA_WILKA = 5;

    public Wilk(Swiat swiat, Punkt pozycja, int turaUrodzenia) {
        super(TypOrganizmu.WILK, swiat, pozycja, turaUrodzenia, SILA_WILKA, INICJATYWA_WILKA);
        this.setZasiegRuchu(ZASIEG_RUCHU_WILKA);
        this.setSzansaWykonywaniaRuchu(SZANSA_WYKONYWANIA_RUCHU_WILKA);
        setKolor(new Color(64, 64, 64));
    }

    @Override
    public String TypOrganizmuToString() {
        return "Wilk";
    }
}

