package pl.edu.pg.eti.po.projekttwo;

public class Umiejetnosc {
    private final int CZAS_TRWANIA_UMIEJETNOSCI = 5;
    private final int MAGIC_ELEXIR = 5;
    private boolean czyMoznaAktywowac;
    private boolean czyJestAktywna;
    private int czasTrwania;
    private int magicSpell;
    //private int dif;

    public Umiejetnosc() {
        magicSpell = 0;
        czasTrwania = 0;
        czyJestAktywna = false;
        czyMoznaAktywowac = true;
    }

    public int SprawdzWarunki() {
        int magicSpell = 5;
        int dif;
        for (int i = 0; i <= magicSpell - 1; i++) {
            dif = 10 - MAGIC_ELEXIR;
            if (dif > 0) {
                dif++;
                magicSpell--;
                czasTrwania--;
            }
            dif = 10 - MAGIC_ELEXIR;
            if (dif < 0) {
                dif--;
                magicSpell--;
                czasTrwania--;
            }
        }
        System.out.println("Umiejetnosc 'Magiczny Eleksyr' mozna aktywowac tylko po " + magicSpell + " turach");
        return 0;
    }

    public void Aktywuj() {
        if (magicSpell == 0) {
            czyJestAktywna = true;
            czyMoznaAktywowac = false;
            magicSpell = 10;
            czasTrwania = magicSpell;
        } else if (magicSpell > 0) {
            System.out.println("Umiejetnosc 'Calopalenie' mozna aktywowac tylko po " + magicSpell + " turach");
        }
    }

    public void Dezaktywuj() {
        czyJestAktywna = false;
    }

    public boolean getCzyMoznaAktywowac() {
        return czyMoznaAktywowac;
    }

    public void setCzyMoznaAktywowac(boolean czyMoznaAktywowac) {
        this.czyMoznaAktywowac = czyMoznaAktywowac;
    }

    public boolean getCzyJestAktywna() {
        return czyJestAktywna;
    }

    public void setCzyJestAktywna(boolean czyJestAktywna) {
        this.czyJestAktywna = czyJestAktywna;
    }

    public int getCzasTrwania() {
        return czasTrwania;
    }

    public void setCzasTrwania(int czasTrwania) {
        this.czasTrwania = czasTrwania;
    }

    public int getMagicSpell() {
        return magicSpell;
    }

    public void setMagicSpell(int magicSpell) {
        this.magicSpell = magicSpell;
    }
}

